/**
 * pi-skill-search — Extension entry point.
 * Implement theo SPEC §7.3, §7.4.
 *
 * Thay the Pi's inject-all pattern bang on-demand search tool + category summary.
 */
import { findCorpusPath, scanSkillDirectory } from "./src/scanner.ts";
import { formatCategorySummary, formatResults, renderToolDescription } from "./src/format.ts";
import { buildIndex, fingerprintSkills } from "./src/indexer.ts";
import { search } from "./src/search.ts";
import { stripAvailableSkillsBlock } from "./src/strip.ts";
import type {
	BeforeAgentStartEvent,
	BeforeAgentStartEventResult,
	ExtensionAPI,
	PiSkill,
	SkillIndex,
} from "./src/types.ts";

/** JSON Schema cho skill-search tool parameters */
const SEARCH_PARAMETERS = {
	type: "object" as const,
	properties: {
		query: { type: "string" as const, description: "Search query — 1 to 500 characters" },
		limit: { type: "number" as const, description: "Max results (1-20, default 5)" },
	},
	required: ["query"],
	additionalProperties: false,
};

/**
 * Merge Pi skills + pss-data skills. Dedupe by name — pss-data wins ties.
 */
function mergeSkills(piSkills: PiSkill[], corpusSkills: PiSkill[]): PiSkill[] {
	if (corpusSkills.length === 0) return piSkills;
	if (piSkills.length === 0) return corpusSkills;
	const byName = new Map<string, PiSkill>();
	for (const s of piSkills) byName.set(s.name, s);
	for (const s of corpusSkills) byName.set(s.name, s); // corpus overwrites
	return [...byName.values()];
}

export default function (pi: ExtensionAPI): void {
	let index: SkillIndex | undefined;
	let lastSkillsFingerprint = "";
	let toolRegistered = false;

	// Find corpus data directory
	const corpusPath = findCorpusPath();
	let corpusSkills: PiSkill[] = [];

	if (corpusPath) {
		corpusSkills = scanSkillDirectory(corpusPath);
		if (corpusSkills.length > 0) {
			console.log(`pi-skill-search: loaded ${corpusSkills.length} skills from ${corpusPath}`);
		}
	} else {
		console.log("pi-skill-search: corpus not found at data/. Run with CORPUS_PATH env var or install pss-corpus package.");
	}

	/**
	 * Build (hoac rebuild) index.
	 * Merge Pi's visible skills + pss-data corpus (dedupe by name, corpus wins).
	 * Corpus skills chi duoc load khi co it nhat 1 Pi skill visible
	 * (khong tao index khi Pi khong co skills nao).
	 * Fingerprint short-circuit de tranh rebuild khong can thiet.
	 */
	function ensureIndex(skills: PiSkill[] | undefined): SkillIndex | undefined {
		const piVisible = (skills ?? []).filter((s) => !s.disableModelInvocation);
		// Chi merge corpus skills khi co it nhat 1 Pi skill visible
		const merged = piVisible.length > 0 ? mergeSkills(piVisible, corpusSkills) : corpusSkills;
		if (merged.length === 0) return undefined;
		const fingerprint = fingerprintSkills(merged);
		if (fingerprint === lastSkillsFingerprint && index) return index;
		try {
			index = buildIndex(merged);
			lastSkillsFingerprint = fingerprint;
			return index;
		} catch (err) {
			console.error("pi-skill-search: index build failed", err);
			return undefined;
		}
	}

	/**
	 * before_agent_start handler:
	 * - Build/rebuild index
	 * - Register skill-search tool (first time only)
	 * - Strip <available_skills> block (ALWAYS — prevent Pi reset)
	 * - Inject category summary (when skills exist)
	 */
	pi.on("before_agent_start", async (event: BeforeAgentStartEvent): Promise<BeforeAgentStartEventResult> => {
		const skills = event.systemPromptOptions?.skills as PiSkill[] | undefined;
		const idx = ensureIndex(skills);

		// ALWAYS strip — if extension returns undefined, Pi resets to
		// baseSystemPrompt which still contains <available_skills> block.
		const stripped = stripAvailableSkillsBlock(event.systemPrompt);

		if (!idx || idx.entries.size === 0) {
			// No skills → strip block nhung khong inject summary
			return { systemPrompt: stripped };
		}

		// Dang ky tool lan dau tien
		if (!toolRegistered) {
			pi.registerTool({
				name: "skill-search",
				label: "Skill Search",
				description: renderToolDescription(idx),
				parameters: SEARCH_PARAMETERS,
				async execute(
					_toolCallId: string,
					input: { query?: string; limit?: number },
					_signal: AbortSignal | undefined,
					_onUpdate: unknown,
					_ctx: unknown,
				) {
					return makeSearchResult(() => index, input);
				},
			});
			toolRegistered = true;
		}

		// Inject category summary
		const summary = formatCategorySummary(idx);
		return { systemPrompt: `${stripped}\n\n${summary}` };
	});
}

/**
 * Xu ly search request voi validation va error handling.
 * Tra ve AgentToolResult format.
 */
function makeSearchResult(
	getIndex: () => SkillIndex | undefined,
	input: { query?: string; limit?: number },
): { content: Array<{ type: "text"; text: string }>; details: Record<string, unknown> } {
	try {
		const idx = getIndex();
		if (!idx || idx.entries.size === 0) {
			return { content: [{ type: "text", text: "No skills indexed." }], details: {} };
		}

		const query = (input.query ?? "").trim();
		if (query.length === 0) {
			return { content: [{ type: "text", text: "Query is required." }], details: {} };
		}
		if (query.length > 500) {
			return { content: [{ type: "text", text: "Query too long (max 500 chars)." }], details: {} };
		}

		// Clamp limit to [1, 20]; default 5
		const rawLimit = input.limit != null && Number.isFinite(input.limit) ? input.limit : 5;
		const limit = Math.max(1, Math.min(20, Math.floor(rawLimit)));

		const results = search(idx, query, limit);
		const text = formatResults(query, results, idx.entries.size);

		return {
			content: [{ type: "text", text }],
			details: { query, resultCount: results.length },
		};
	} catch (err) {
		const message = err instanceof Error ? err.message : String(err);
		console.error("pi-skill-search: search failed", err);
		return { content: [{ type: "text", text: `Search failed: ${message}` }], details: {} };
	}
}